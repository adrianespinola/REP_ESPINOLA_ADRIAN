from django.shortcuts import render
from NuevaApp.models import Familiar1
from NuevaApp.models import Familiar2
from NuevaApp.models import Familiar3
from django.http import HttpResponse

# Create your views here.


def familiares(self):
    familiar1=Familiar1(nombre_completo="Ivana Zar", edad=27,fecha_nacimiento="1995-01-01")
    familiar1.save()
    familiar2=Familiar2(nombre_completo="Catalina Suki", edad=22,fecha_nacimiento="2000-01-01")
    familiar2.save()
    familiar3=Familiar3(nombre_completo="Adrian Kha", edad=20,fecha_nacimiento="2022-06-06")
    familiar3.save()

    texto=f"Familiar 1 creado: {familiar1.nombre_completo} {familiar1.edad} {familiar1.fecha_nacimiento} \n - familiar 2 creado: {familiar2.nombre_completo} {familiar2.edad} {familiar2.fecha_nacimiento} \n - familiar 3 creado: {familiar3.nombre_completo} {familiar3.edad} {familiar3.fecha_nacimiento}"
    return HttpResponse(texto)
'''
def familiar1(self):
    familiar1=Familiar1(nombre_completo="Ivana Zar", edad=27,fecha_nacimiento="1995-01-01")
    familiar1.save()
    texto=f"Familiar 1: {familiar1.nombre_completo} {familiar1.edad} {familiar1.fecha_nacimiento}"
    return HttpResponse(texto)


def familiar2(self):
    familiar2=Familiar2(nombre_completo="Catalina Suki", edad=22,fecha_nacimiento="2000-01-01")
    familiar2.save()
    texto=f"Familiar 2: {familiar2.nombre_completo} {familiar2.edad} {familiar2.fecha_nacimiento}"
    return HttpResponse(texto)   

def familiar3(self):
    familiar3=Familiar3(nombre_completo="Adrian Kha", edad=20,fecha_nacimiento="2022-06-06")
    familiar3.save()
    texto=f"Familiar 3: {familiar3.nombre_completo} {familiar3.edad} {familiar3.fecha_nacimiento}"
    return HttpResponse(texto) 
'''