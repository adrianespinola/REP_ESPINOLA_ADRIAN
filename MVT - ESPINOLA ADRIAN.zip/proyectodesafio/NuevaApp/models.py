from django.db import models

# Create your models here.

class Familiar1(models.Model):
    nombre_completo = models.CharField(max_length=30)
    edad = models.IntegerField()
    fecha_nacimiento = models.DateField()

    
class Familiar2(models.Model):
    nombre_completo = models.CharField(max_length=30)
    edad = models.IntegerField()
    fecha_nacimiento = models.DateField()

class Familiar3(models.Model):
    nombre_completo = models.CharField(max_length=30)
    edad = models.IntegerField()
    fecha_nacimiento = models.DateField()